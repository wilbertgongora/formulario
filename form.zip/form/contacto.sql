CREATE DATABASE Contacto;
use Contacto;
CREATE TABLE FORMULARIO(
ID int auto_increment primary key,
Nombre varchar(255),
Apellido varchar(255),
gmail varchar(255),
consulta varchar(255),
mensaje varchar(255)



)

